bool riseFlag = false;
int rotaryDetectionCount = 0;

void wheel_distance_calculator(uint gpio, uint32_t events) {
    if((events & GPIO_IRQ_EDGE_RISE)){
        rotaryDetectionCount++;
        riseFlag = true;
    }
    else if((events & GPIO_IRQ_EDGE_FALL)){
        riseFlag = false;
        notch_count += 1;
    }

    if(rotaryDetectionCount == SINGLELOOP){
        //1 round completed
        rotaryDetectionCount = 0;
        totalDistanceTravaled += LOOPCIRCUMFERENCEINCM;
    }
}