#ifndef ULTRASONIC_H
#define ULTRASONIC_H

volatile float latest_distance_cm;
uint32_t start_time, end_time;

void echo_interrupt_handler();
void irq_callback(uint gpio, uint32_t events);

#endif // ULTRASONIC_H

void echo_interrupt_handler(uint gpio, uint32_t events) {
    if(events & GPIO_IRQ_EDGE_RISE){
        start_time = time_us_32();
    }
    else if (events & GPIO_IRQ_EDGE_FALL){
        end_time = time_us_32();
        uint32_t duration = end_time - start_time;
        float distance = (float)duration * SPEED_OF_SOUND_CM_US / 2.0;
        if(distance <= OBJECT_DETECTION_THRESHOLD){
            object_detected = true;
        }
        else{
            object_detected = false;
        }
    }
}

void ultrasonic_init(){
    gpio_init(TRIGGER_PIN);
    gpio_set_dir(TRIGGER_PIN, GPIO_OUT);

    gpio_init(ECHO_PIN);
    gpio_set_dir(ECHO_PIN, GPIO_IN);

    gpio_set_irq_enabled_with_callback(ECHO_PIN, GPIO_IRQ_EDGE_RISE | GPIO_IRQ_EDGE_FALL, true, &irq_callback);
}

void trigger_pulse(){
    gpio_put(TRIGGER_PIN, 1);
    sleep_us(10);
    gpio_put(TRIGGER_PIN, 0);
}