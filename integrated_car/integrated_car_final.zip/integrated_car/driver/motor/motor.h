void irq_callback(uint gpio, uint32_t events);

void moveWheel(uint pin, bool rotaryDirection){
    gpio_init(pin);
    gpio_set_dir(pin, rotaryDirection);
    gpio_put(pin, 1);
}

// void test_route(int direction){
//     wheelSpeed(RIGHT_WHEEL_PWM_PIN, PWM_CHAN_B, current_speed);
//     wheelSpeed(LEFT_WHEEL_PWM_PIN, PWM_CHAN_A, current_speed);

//     switch (direction)
//     {
//         case FORWARD:
//             moveWheel(LEFT_WHEEL_PWM_2, GPIO_OUT);
//             moveWheel(RIGHT_WHEEL_PWM_2, GPIO_OUT);
            
//             moveWheel(LEFT_WHEEL_PWM_1, GPIO_OUT);
//             moveWheel(RIGHT_WHEEL_PWM_1, GPIO_OUT);
//             break;
//         case LEFT:
//             moveWheel(RIGHT_WHEEL_PWM_2, GPIO_OUT);
//             moveWheel(LEFT_WHEEL_PWM_1, GPIO_OUT);

//             moveWheel(RIGHT_WHEEL_PWM_1, GPIO_OUT);
//             moveWheel(LEFT_WHEEL_PWM_2, GPIO_OUT);
//             break;
//         case RIGHT:
//             moveWheel(LEFT_WHEEL_PWM_2, GPIO_OUT);
//             moveWheel(RIGHT_WHEEL_PWM_1, GPIO_OUT);

//             moveWheel(LEFT_WHEEL_PWM_1, GPIO_OUT);
//             moveWheel(RIGHT_WHEEL_PWM_2, GPIO_OUT);
//             break;
//         default:
//             break;
//     }
// }

void resetWheel(){
    gpio_put(LEFT_WHEEL_PWM_1, 0);
    gpio_put(LEFT_WHEEL_PWM_2, 0);
    gpio_put(RIGHT_WHEEL_PWM_1, 0);
    gpio_put(RIGHT_WHEEL_PWM_2, 0);
    gpio_set_irq_enabled_with_callback(LEFT_IR_PIN, GPIO_IRQ_EDGE_RISE | GPIO_IRQ_EDGE_FALL, false, &irq_callback);
    gpio_set_irq_enabled_with_callback(RIGHT_IR_PIN, GPIO_IRQ_EDGE_RISE | GPIO_IRQ_EDGE_FALL, false, &irq_callback);
}

void wheel_irq_switch(int wheel_irq){
    if(wheel_irq == LEFT){
        gpio_set_irq_enabled_with_callback(LEFT_IR_PIN, GPIO_IRQ_EDGE_RISE | GPIO_IRQ_EDGE_FALL, false, &irq_callback);
        gpio_set_irq_enabled_with_callback(RIGHT_IR_PIN, GPIO_IRQ_EDGE_RISE | GPIO_IRQ_EDGE_FALL, true, &irq_callback);
    }
    else if (wheel_irq == RIGHT){
        gpio_set_irq_enabled_with_callback(LEFT_IR_PIN, GPIO_IRQ_EDGE_RISE | GPIO_IRQ_EDGE_FALL, true, &irq_callback);
        gpio_set_irq_enabled_with_callback(RIGHT_IR_PIN, GPIO_IRQ_EDGE_RISE | GPIO_IRQ_EDGE_FALL, false, &irq_callback);
    }
}

void wheelSpeed(uint pin, uint channel, uint speed){
    gpio_set_function(pin, GPIO_FUNC_PWM);
    
    uint slice_num = pwm_gpio_to_slice_num(pin);
    
    // debouncing straight
    pwm_set_clkdiv(slice_num, 100);//125Mhz / 100 = 1.25Mhz = 1250000hz
    pwm_set_wrap(slice_num, 31250);//1250000hz / 6250 = 25hz
    pwm_set_chan_level(slice_num, channel, 31250/speed);
    pwm_set_enabled(slice_num, true);

    //turn right
//    pwm_set_clkdiv(slice_num, 100);//125Mhz / 100 = 1.25Mhz = 1250000hz
//     pwm_set_wrap(slice_num, 31250);//1250000hz / 6250 = 25hz
//     pwm_set_chan_level(slice_num, channel, 31250/speed);
//     pwm_set_enabled(slice_num, true);
}
